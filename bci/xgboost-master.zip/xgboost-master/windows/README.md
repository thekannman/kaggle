The solution has been created with Visual Studio Express 2010.
Make sure to compile the Release version, unless you need to debug the code 
(and in the latter case modify the path in xgboost.py from release to test).
Note that you have two projects in one solution and they need to be compiled to use the standalone executable from the command line 
or the python module respectively.